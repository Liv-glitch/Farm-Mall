import Joi from 'joi';

// Common validation schemas
export const idSchema = Joi.string().uuid().required();
export const emailSchema = Joi.string().email().optional();
export const phoneSchema = Joi.string().pattern(/^\+?[1-9]\d{1,14}$/).optional();
export const passwordSchema = Joi.string().min(8).pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/).required();
export const locationSchema = Joi.object({
  latitude: Joi.number().min(-90).max(90).required(),
  longitude: Joi.number().min(-180).max(180).required(),
});

// Authentication validation schemas
export const registerSchema = Joi.object({
  fullName: Joi.string().min(2).max(255).required(),
  email: emailSchema,
  phoneNumber: phoneSchema,
  password: passwordSchema,
  county: Joi.string().min(2).max(100).required(),
  subCounty: Joi.string().min(2).max(100).required(),
  locationLat: Joi.number().min(-90).max(90).optional(),
  locationLng: Joi.number().min(-180).max(180).optional(),
}).or('email', 'phoneNumber');

export const loginSchema = Joi.object({
  identifier: Joi.string().required(),
  password: Joi.string().required(),
});

export const changePasswordSchema = Joi.object({
  currentPassword: Joi.string().required(),
  newPassword: passwordSchema,
});

export const resetPasswordSchema = Joi.object({
  identifier: Joi.string().required(),
});

export const confirmResetPasswordSchema = Joi.object({
  token: Joi.string().required(),
  newPassword: passwordSchema,
});

export const verifyEmailSchema = Joi.object({
  token: Joi.string().required(),
});

export const verifyPhoneSchema = Joi.object({
  phoneNumber: phoneSchema.required(),
  verificationCode: Joi.string().length(6).pattern(/^\d+$/).required(),
});

// User profile validation schemas
export const updateProfileSchema = Joi.object({
  fullName: Joi.string().min(2).max(255).optional(),
  email: emailSchema,
  phoneNumber: phoneSchema,
  county: Joi.string().min(2).max(100).optional(),
  subCounty: Joi.string().min(2).max(100).optional(),
  locationLat: Joi.number().min(-90).max(90).optional(),
  locationLng: Joi.number().min(-180).max(180).optional(),
});

// Production cycle validation schemas
export const createProductionCycleSchema = Joi.object({
  cropVarietyId: idSchema,
  landSizeAcres: Joi.number().min(0.1).max(10000).precision(2).required(),
  farmLocation: Joi.string().max(255).optional(),
  farmLocationLat: Joi.number().min(-90).max(90).optional(),
  farmLocationLng: Joi.number().min(-180).max(180).optional(),
  plantingDate: Joi.date().optional(),
});

export const updateProductionCycleSchema = Joi.object({
  cropVarietyId: idSchema.optional(),
  landSizeAcres: Joi.number().min(0.1).max(10000).precision(2).optional(),
  farmLocation: Joi.string().max(255).optional(),
  farmLocationLat: Joi.number().min(-90).max(90).optional(),
  farmLocationLng: Joi.number().min(-180).max(180).optional(),
  plantingDate: Joi.date().optional(),
  estimatedHarvestDate: Joi.date().optional(),
  actualHarvestDate: Joi.date().max('now').optional(),
  status: Joi.string().valid('planning', 'active', 'harvested', 'archived').optional(),
  totalYieldKg: Joi.number().min(0).precision(2).optional(),
});

// Activity validation schemas
export const createActivitySchema = Joi.object({
  activityType: Joi.string().min(2).max(100).required(),
  activityDate: Joi.date().max('now').required(),
  cost: Joi.number().min(0).precision(2).optional(),
  laborType: Joi.string().valid('manual', 'mechanized').optional(),
  laborCost: Joi.number().min(0).precision(2).optional(),
  notes: Joi.string().max(1000).optional(),
  inputs: Joi.array().items(
    Joi.object({
      itemName: Joi.string().min(1).max(255).required(),
      quantity: Joi.number().min(0).precision(2).required(),
      unit: Joi.string().min(1).max(50).required(),
      unitCost: Joi.number().min(0).precision(2).required(),
      brandSupplier: Joi.string().max(255).optional(),
      receiptImageUrl: Joi.string().uri().optional(),
    })
  ).optional(),
});

export const updateActivitySchema = Joi.object({
  activityType: Joi.string().min(2).max(100).optional(),
  activityDate: Joi.date().max('now').optional(),
  cost: Joi.number().min(0).precision(2).optional(),
  laborType: Joi.string().valid('manual', 'mechanized').optional(),
  laborCost: Joi.number().min(0).precision(2).optional(),
  notes: Joi.string().max(1000).optional(),
});

// Calculator validation schemas
export const costCalculationSchema = Joi.object({
  cropVarietyId: Joi.string().uuid().required(),
  landSizeAcres: Joi.number().min(0.1).max(10000).precision(2).required(),
  seedSize: Joi.number().valid(1, 2).required(),
  location: Joi.object({
    county: Joi.string().min(2).max(100).required(),
    subCounty: Joi.string().min(2).max(100).required(),
  }).optional(),
});

export const harvestPredictionSchema = Joi.object({
  cropVarietyId: Joi.string().uuid().required(),
  plantingDate: Joi.date().required(),
  landSizeAcres: Joi.number().min(0.1).max(10000).precision(2).required(),
  location: locationSchema.optional(),
});

// AI & Weather validation schemas
export const pestAnalysisSchema = Joi.object({
  cropType: Joi.string().min(2).max(100).required(),
  location: locationSchema.required(),
  farmingStage: Joi.string().max(100).optional(),
  symptoms: Joi.array().items(Joi.string().max(255)).optional(),
});

// Form-data specific schema for multipart uploads
export const pestAnalysisFormDataSchema = Joi.object({
  cropType: Joi.string().min(2).max(100).required(),
  location: Joi.string().custom((value, helpers) => {
    try {
      const parsed = JSON.parse(value);
      const { error, value: validatedLocation } = locationSchema.validate(parsed);
      if (error) {
        return helpers.error('location.invalid');
      }
      return validatedLocation;
    } catch (parseError) {
      return helpers.error('location.parse');
    }
  }).required().messages({
    'location.invalid': 'Location must be a valid object with latitude and longitude',
    'location.parse': 'Location must be a valid JSON string'
  }),
  farmingStage: Joi.string().max(100).optional(),
  symptoms: Joi.string().custom((value, helpers) => {
    try {
      const parsed = JSON.parse(value);
      const { error, value: validatedSymptoms } = Joi.array().items(Joi.string().max(255)).validate(parsed);
      if (error) {
        return helpers.error('symptoms.invalid');
      }
      return validatedSymptoms;
    } catch (parseError) {
      return helpers.error('symptoms.parse');
    }
  }).optional().messages({
    'symptoms.invalid': 'Symptoms must be an array of strings',
    'symptoms.parse': 'Symptoms must be a valid JSON array string'
  }),
});

export const weatherRequestSchema = Joi.object({
  location: locationSchema.required(),
  startDate: Joi.date().optional(),
  endDate: Joi.date().min(Joi.ref('startDate')).optional(),
  forecastType: Joi.string().valid('current', 'daily', 'extended', 'seasonal').required(),
});

export const eventSchema = Joi.object({
  name: Joi.string().trim().min(1).max(255).required().messages({
    'any.required': 'name is required',
    'string.empty': 'name is required',
  }),
  date: Joi.date().required().messages({
    'any.required': 'date is required',
    'date.base': 'date must be a valid date',
  }),
  mode: Joi.string().valid('online', 'physical').required().messages({
    'any.required': 'mode is required',
    'any.only': 'mode must be either online or physical',
  }),
  location: Joi.when('mode', {
    is: 'physical',
    then: Joi.string().trim().min(1).required().messages({
      'any.required': 'location is required for physical events',
      'string.empty': 'location is required for physical events',
    }),
    otherwise: Joi.string().allow('', null).optional(),
  }),
  registration_link: Joi.string().uri({ scheme: ['http', 'https'] }).required().messages({
    'any.required': 'registration_link is required',
    'string.empty': 'registration_link is required',
    'string.uri': 'registration_link must be a valid URL',
  }),
  registrationLink: Joi.string().uri({ scheme: ['http', 'https'] }).optional(),
  description: Joi.string().trim().min(1).required().messages({
    'any.required': 'description is required',
    'string.empty': 'description is required',
  }),
}).or('registration_link', 'registrationLink');

// Image upload validation
export const imageUploadSchema = Joi.object({
  file: Joi.object({
    mimetype: Joi.string().valid('image/jpeg', 'image/png', 'image/webp').required(),
    size: Joi.number().max(10 * 1024 * 1024).required(), // 10MB limit
  }).required(),
});

// Pagination validation
export const paginationSchema = Joi.object({
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(20),
  sortBy: Joi.string().optional(),
  sortOrder: Joi.string().valid('asc', 'desc').default('desc'),
});

// Query parameter validation
export const queryParamsSchema = Joi.object({
  search: Joi.string().max(255).optional(),
  status: Joi.string().valid('planning', 'active', 'harvested', 'archived').optional(),
  cropType: Joi.string().max(100).optional(),
  startDate: Joi.date().optional(),
  endDate: Joi.date().min(Joi.ref('startDate')).optional(),
}).concat(paginationSchema);

// Kenya-specific validations
export const kenyaCounties = [
  'Baringo', 'Bomet', 'Bungoma', 'Busia', 'Elgeyo-Marakwet', 'Embu', 'Garissa',
  'Homa Bay', 'Isiolo', 'Kajiado', 'Kakamega', 'Kericho', 'Kiambu', 'Kilifi',
  'Kirinyaga', 'Kisii', 'Kisumu', 'Kitui', 'Kwale', 'Laikipia', 'Lamu',
  'Machakos', 'Makueni', 'Mandera', 'Marsabit', 'Meru', 'Migori', 'Mombasa',
  'Murang\'a', 'Nairobi', 'Nakuru', 'Nandi', 'Narok', 'Nyamira', 'Nyandarua',
  'Nyeri', 'Samburu', 'Siaya', 'Taita-Taveta', 'Tana River', 'Tharaka-Nithi',
  'Trans Nzoia', 'Turkana', 'Uasin Gishu', 'Vihiga', 'Wajir', 'West Pokot'
];

export const kenyaCountySchema = Joi.string().valid(...kenyaCounties);

// Custom validation functions
export const validateKenyaPhoneNumber = (phoneNumber: string): boolean => {
  // Kenya phone number patterns: +254XXXXXXXXX or 07XXXXXXXX or 01XXXXXXXX
  const patterns = [
    /^\+254[71]\d{8}$/, // International format
    /^0[17]\d{8}$/, // Local format
  ];
  return patterns.some(pattern => pattern.test(phoneNumber));
};

export const validateCoordinatesInKenya = (lat: number, lng: number): boolean => {
  // Kenya is approximately between -4.7°N to 5.0°N and 33.9°E to 41.9°E
  return lat >= -4.7 && lat <= 5.0 && lng >= 33.9 && lng <= 41.9;
};

export const formatPhoneNumber = (phoneNumber: string): string => {
  // Remove all non-digit characters except +
  let cleaned = phoneNumber.replace(/[^\d+]/g, '');
  
  // If it starts with 0, replace with +254 (Kenya)
  if (cleaned.startsWith('0')) {
    cleaned = '+254' + cleaned.substring(1);
  }
  
  // If it doesn't start with +, add it
  if (!cleaned.startsWith('+')) {
    cleaned = '+' + cleaned;
  }
  
  return cleaned;
};

// Validation result interface
export interface ValidationResult {
  isValid: boolean;
  errors?: string[];
}

// Helper function to validate with Joi schema
export const validateWithSchema = (schema: Joi.ObjectSchema, data: any): ValidationResult => {
  const { error } = schema.validate(data, { abortEarly: false });
  
  if (error) {
    return {
      isValid: false,
      errors: error.details.map(detail => detail.message),
    };
  }
  
  return { isValid: true };
};

export const validateEventRequest = (data: any): ValidationResult => {
  const normalized = {
    ...data,
    registration_link: data.registration_link ?? data.registrationLink,
  };

  const { error } = eventSchema.validate(normalized, { abortEarly: false });

  if (error) {
    return {
      isValid: false,
      errors: error.details.map(detail => {
        const field = detail.path.join('.') || 'event';
        return `${field}: ${detail.message.replace(/"/g, '')}`;
      }),
    };
  }

  return { isValid: true };
};

// Specific validation functions expected by the controller
export const validateRegisterRequest = (data: any): ValidationResult => {
  // Format phone number if provided
  if (data.phoneNumber) {
    try {
      data.phoneNumber = formatPhoneNumber(data.phoneNumber);
    } catch (error) {
      // If formatting fails, keep original for validation
    }
  }
  
  const result = validateWithSchema(registerSchema, data);
  
  // Add custom error messages for phone number validation
  if (!result.isValid && result.errors) {
    result.errors = result.errors.map(error => {
      if (error.includes('phoneNumber') && error.includes('pattern')) {
        return 'Phone number must be in international format (e.g., +254712345678 for Kenya, +1234567890 for US)';
      }
      return error;
    });
  }
  
  return result;
};

export const validateLoginRequest = (data: any): ValidationResult => {
  return validateWithSchema(loginSchema, data);
};

export const validateChangePasswordRequest = (data: any): ValidationResult => {
  return validateWithSchema(changePasswordSchema, data);
};

export const validatePasswordResetRequest = (data: any): ValidationResult => {
  return validateWithSchema(resetPasswordSchema, data);
};

export const validateVerifyEmailRequest = (data: any): ValidationResult => {
  return validateWithSchema(verifyEmailSchema, data);
};

export const validateVerifyPhoneRequest = (data: any): ValidationResult => {
  return validateWithSchema(verifyPhoneSchema, data);
};

// Validation helper function
export const validateSchema = async (schema: Joi.ObjectSchema, data: any): Promise<any> => {
  try {
    const { error, value } = schema.validate(data, {
      abortEarly: false,
      stripUnknown: true,
      convert: true,
    });

    if (error) {
      const errors = error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message,
      }));
      throw new Error(`Validation failed: ${JSON.stringify(errors)}`);
    }

    return value;
  } catch (error) {
    throw error;
  }
};

// Middleware validation wrapper
export const validate = (schema: Joi.ObjectSchema) => {
  return (req: any, res: any, next: any) => {
    const { error, value } = schema.validate(req.body, {
      abortEarly: false,
      stripUnknown: true,
      convert: true,
    });

    if (error) {
      const errors = error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message,
      }));
      
      return res.status(400).json({
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Request validation failed',
          details: errors,
        },
        timestamp: new Date().toISOString(),
        path: req.path,
      });
    }

    req.body = value;
    next();
  };
};

export default {
  registerSchema,
  loginSchema,
  changePasswordSchema,
  updateProfileSchema,
  createProductionCycleSchema,
  updateProductionCycleSchema,
  createActivitySchema,
  updateActivitySchema,
  costCalculationSchema,
  harvestPredictionSchema,
  pestAnalysisSchema,
  pestAnalysisFormDataSchema,
  weatherRequestSchema,
  imageUploadSchema,
  paginationSchema,
  queryParamsSchema,
  validate,
  validateSchema,
  validateRegisterRequest,
  validateLoginRequest,
  validateChangePasswordRequest,
  validatePasswordResetRequest,
  validateVerifyEmailRequest,
  validateVerifyPhoneRequest,
}; 
