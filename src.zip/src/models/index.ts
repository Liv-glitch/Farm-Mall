import { Sequelize } from 'sequelize';
import { UserModel, initializeUserModel } from './User.model';
import { ProductionCycleModel } from './ProductionCycle.model';
import { CropVarietyModel } from './CropVariety.model';
import { ActivityModel } from './Activity.model';
import { FarmCollaboratorModel } from './FarmCollaborator.model';
import { PestAnalysisModel } from './PestAnalysis.model';
import { WeatherRequestModel } from './WeatherRequest.model';
import { FarmModel } from './Farm.model';
import { SoilTestModel, initializeSoilTestModel } from './SoilTest.model';
import { PlantIdentificationModel, initializePlantIdentificationModel } from './PlantIdentification.model';
import { PlantHealthAssessmentModel, initializePlantHealthAssessmentModel } from './PlantHealthAssessment.model';
import { Media } from './Media.model';
import { MediaAssociation } from './MediaAssociation.model';
import { PreproductionPlanModel, initializePreproductionPlanModel } from './PreproductionPlan.model';
import { PreproductionStepModel, initializePreproductionStepModel } from './PreproductionStep.model';
import { PreproductionTaskModel, initializePreproductionTaskModel } from './PreproductionTask.model';
import { EventModel } from './Event.model';

// Initialize all models with the sequelize instance
export function initializeModels(sequelize: Sequelize): void {
  // Initialize User model
  initializeUserModel(sequelize);
  
  // Initialize SoilTest model
  initializeSoilTestModel(sequelize);
  
  // Initialize Plant models
  initializePlantIdentificationModel(sequelize);
  initializePlantHealthAssessmentModel(sequelize);
  
  // Initialize Media models
  Media.initModel(sequelize);
  MediaAssociation.initModel(sequelize);

  // Initialize Pre-production planning models
  initializePreproductionPlanModel(sequelize);
  initializePreproductionStepModel(sequelize);
  initializePreproductionTaskModel(sequelize);
  
  // Other models are already initialized in their respective files
  // through their .init() calls at the bottom
  
  // Set up model associations after all models are initialized
  setupAssociations();
  
  console.log('📋 All database models initialized with associations successfully.');
}

// Set up model associations
function setupAssociations(): void {
  UserModel.associate({
    ProductionCycle: ProductionCycleModel,
    PestAnalysis: PestAnalysisModel,
    WeatherRequest: WeatherRequestModel,
    Farm: FarmModel,
    SoilTest: SoilTestModel,
    Event: EventModel,
  });

  ProductionCycleModel.associate({
    User: UserModel,
    CropVariety: CropVarietyModel,
    Activity: ActivityModel,
    PestAnalysis: PestAnalysisModel,
    Farm: FarmModel
  });

  CropVarietyModel.associate({
    ProductionCycle: ProductionCycleModel,
  });

  ActivityModel.associate({
    User: UserModel,
    ProductionCycle: ProductionCycleModel,
  });

  FarmCollaboratorModel.associate({
    User: UserModel,
    Farm: FarmModel,
  });

  PestAnalysisModel.associate({
    User: UserModel,
    ProductionCycle: ProductionCycleModel,
  });

  WeatherRequestModel.associate({
    User: UserModel,
  });

  FarmModel.associate({
    User: UserModel,
    ProductionCycle: ProductionCycleModel,
    FarmCollaborator: FarmCollaboratorModel,
    SoilTest: SoilTestModel,
  });

  SoilTestModel.associate({
    User: UserModel,
    Farm: FarmModel,
  });

  // Plant model associations
  PlantIdentificationModel.associate({
    User: UserModel,
  });

  PlantHealthAssessmentModel.associate({
    User: UserModel,
  });

  // Media associations
  Media.belongsTo(UserModel, { foreignKey: 'userId', as: 'user' });
  MediaAssociation.belongsTo(Media, { foreignKey: 'mediaId', as: 'Media' });
  Media.hasMany(MediaAssociation, { foreignKey: 'mediaId', as: 'associations' });

  // Pre-production planning associations
  PreproductionPlanModel.associate({
    User: UserModel,
    PreproductionStep: PreproductionStepModel,
  });

  PreproductionStepModel.associate({
    PreproductionPlan: PreproductionPlanModel,
    PreproductionTask: PreproductionTaskModel,
  });

  PreproductionTaskModel.associate({
    PreproductionStep: PreproductionStepModel,
  });

  EventModel.associate({
    User: UserModel,
  });
}

// Export models for use throughout the application
export {
  UserModel,
  ProductionCycleModel,
  CropVarietyModel,
  ActivityModel,
  FarmCollaboratorModel,
  PestAnalysisModel,
  WeatherRequestModel,
  FarmModel,
  SoilTestModel,
  PlantIdentificationModel,
  PlantHealthAssessmentModel,
  Media,
  MediaAssociation,
  PreproductionPlanModel,
  PreproductionStepModel,
  PreproductionTaskModel,
  EventModel,
};

// Export types
export * from './User.model';
export * from './ProductionCycle.model';
export * from './CropVariety.model';
export * from './Activity.model';
export * from './SoilTest.model';
export * from './Media.model';
export * from './MediaAssociation.model';
export * from './PreproductionPlan.model';
export * from './PreproductionStep.model';
export * from './PreproductionTask.model';
export * from './Event.model';
